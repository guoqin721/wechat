var WXGrid = require('../wxgrid/wxgrid.js')
var wxgrid = new WXGrid;
wxgrid.init(2,3);
wxgrid.setRowsHeight(100,0);
wxgrid.setRowsHeight(100,1);
var classifies = [
  {name:"领聘1"},
  {name:"领聘2"},
  {name:"领聘3"},
  {name:"领聘4"},
  {name:"领聘5"},
  {name:"领聘6"}]
wxgrid.data.add("classifies",classifies);   //将一维数组转换为二维数组
var app = getApp()
Page({
  data: {
    wxgrid
  }
})